<?php 
/**
* 
*/
class Smart
{
	public function FunctionName($value='')
	{
		# code...
	}
}