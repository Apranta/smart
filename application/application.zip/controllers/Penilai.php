<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penilai extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->data['username']      = $this->session->userdata('username');
        $this->data['role']  = $this->session->userdata('role');
        if (!isset($this->data['username'], $this->data['role']))
        {
            $this->session->sess_destroy();
            redirect('login');
            exit;
        }
        if ($this->data['role'] != 4)
        {
            $this->session->sess_destroy();
            redirect('login');
            exit;
        }
        $this->load->model('Pegawai_m');
        $this->load->model('Kriteria_m');
        $this->load->model('Manager_m');
        $this->load->model('Penilaian_m');
        $this->load->model('Nilai_kriteria_m');
        $this->data['user'] = $this->Manager_m->get_row(['username' => $this->data['username']]);
        $this->data['kriteria']     =   $this->Kriteria_m->get(); 
    }

    public function index()
    {
        // print_r($this->data['user']);exit;
        if ($this->POST('input') && $this->POST('username')) {
            // echo $this->POST('username');exit;
            foreach ($this->data['kriteria'] as $kriteria) {
                $this->data['entry']    = [
                    'pegawai' => $this->POST('username'),
                    'kriteria'  => $kriteria->id,
                    'nilai'     => $this->POST($kriteria->nama)
                ];
                // $this->Penilaian_saw_m->insert($this->data['entry']);

            }
            redirect('direktur','refresh');
            exit;
        }
        
        $this->data['data']         = $this->Pegawai_m->get();
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'direktur/dashboard';
        $this->template($this->data);
    }

    public function data_pegawai()
    {
        $this->data['data']         = $this->Pegawai_m->get();
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'direktur/data_pegawai';
        $this->template($this->data);
    }

    public function detail_pegawai()
    {
        $this->data['data']         = $this->Pegawai_m->get();
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'direktur/detail-pegawai';
        $this->template($this->data);
    }

    public function penilaian()
    {
        if ($this->POST('simpan')) {
            foreach ($this->Kriteria_m->get() as $kri) {
                # code...
                $this->Penilaian_m->insert([
                    'id_pegawai'    => $this->POST('id_pegawai'),
                    'id_kriteria'   => $kri->id,
                    'nilai'         => $this->POST($kri->id)
                ]);
            }
            redirect('direktur/penilaian');
            exit;
        }
        if ($this->POST('submit')) {
            $nilai = $this->nilai();
            foreach ($nilai as $key => $value) {
                if ($value >= 75) {
                    $this->Pegawai_m->update($key , ['wawancara' => 1]);
                }
                else
                    $this->Pegawai_m->update($key , ['wawancara' => 9]);
            }
            echo "berhasil";
            exit;
        }
        $this->data['data']         = $this->Pegawai_m->get();
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'direktur/hasil_penilaian';
        $this->template($this->data);
    }

    public function nilai_pegawai()
    {
        // echo "<pre>" . json_encode($totalp , JSON_PRETTY_PRINT) . "</pre>";exit;
        $this->data['total'] = $this->nilai();
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']       = 'admin/nilai_pegawai';
        $this->template($this->data);
    }

    public function nilai()
    {
        $this->load->model(['Nilai_kriteria_m','Penilaian_m']);
        $this->data['data']          = $this->Pegawai_m->get();
        $i=0; 
        $totalp = [];
        $total = [];
        foreach ($this->data['data'] as $pegawai){
            $total[$pegawai->username] = 0;
            foreach ($this->Kriteria_m->get() as $kri){
                $nilai = $this->Penilaian_m->get_row(['id_pegawai' => $pegawai->username , 'id_kriteria' => $kri->id]);
                if (!isset($nilai)) {
                    $total[$pegawai->username]+=0;
                }
                else{
                    $total[$pegawai->username]+=$nilai->nilai;
                }
            }
            $totalp[$pegawai->username] = 0;
            foreach ($this->Kriteria_m->get() as $kri){
                $nilai = $this->Penilaian_m->get_row(['id_pegawai' => $pegawai->username , 'id_kriteria' => $kri->id]);
                    if (!isset($nilai)) {
                        $totalp[$pegawai->username]+=0;
                    }
                    else{
                        $val = ($this->Nilai_kriteria_m->get_row(['id' => $nilai->nilai])) ? $this->Nilai_kriteria_m->get_row(['id' => $nilai->nilai])->bobot : 0;
                        $nilai_uti = $this->Nilai_kriteria_m->getUtiliti($val , $kri->id);
                        $hasil = $nilai_uti * ($kri->bobot / $this->Kriteria_m->get_total()->bobot);
                        $totalp[$pegawai->username]+=round( $hasil , 3 ) * 100;
                        // $bobot = $this->Nilai_kriteria_m->get_row(['nilai' => $nilai->nilai])->bobot;
                        // $bobot = $this->Nilai_kriteria_m->getUtiliti($bobot , $kri->id);
                        // $hasil = round($bobot * ($nilai->nilai/$total[$pegawai->username]) , 3);
                        // $totalp[$pegawai->username]+=$hasil;
                    }
            }
        }    
        arsort($totalp);
        return $totalp;
    }
}