<?php

class Pegawai extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->data['username']      = $this->session->userdata('username');
                $this->data['role']  = $this->session->userdata('role');
                if (!isset($this->data['username'], $this->data['role']))
                {
                    $this->session->sess_destroy();
                    redirect('login');
                    exit;
                }

                if ($this->data['role'] != 3)
                {
                    $this->session->sess_destroy();
                    redirect('login');
                    exit;
                }
		$this->load->model(['Pegawai_m' , 'Penilaian_m' , 'Kriteria_m' , 'Data_berkas_m' , 'Tes_tertulis_m']);
		$this->data['user'] = $this->Pegawai_m->get_row(['username' => $this->data['username']]);
	}

	public function index($value='')
	{
		
		$this->data['title']                  = 'Dashboard Admin';
                $this->data['content']        = 'pegawai/dashboard';
                $this->template($this->data);
	}

	public function profile($value='')
	{
		$this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'pegawai/profile';
        $this->template($this->data);
	}

    public function edit_profile($value='')
    {
        if ($this->POST('simpan')) {
            $this->Pegawai_m->update($this->data['username'] , [
                'nama'          => $this->POST('nama'),
                'tempat_lahir'  => $this->POST('tempat_lahir'),
                'tanggal_lahir' => $this->POST('tanggal_lahir'),
                'alamat'        => $this->POST('alamat'),
                'pendidikan'    => $this->POST('pendidikan'),
                'telepon'       => $this->POST('telepon'),
            ]);
            redirect('pegawai/profile');exit;
        }
        if ($this->POST('simpan-foto')) {
            # code...
            if (!empty($_FILES['foto']['name'])){
                // echo $this->data['username'];exit;
                $this->upload($this->data['username'],'user', 'foto');
            }
            redirect('pegawai/profile');exit;
        }
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'pegawai/edit_profile';
        $this->template($this->data);
    }

    public function detail_hasil($value='')
    {
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'pegawai/detail_hasil';
        $this->template($this->data);
    }

    public function berkas()
    {
        # code...
        if ($this->POST('upload')) {
            # code...
            $this->Data_berkas_m->insert(['id_pegawai' => $this->data['username'] , 'nama' => $this->POST('nama')]);
            if (!empty($_FILES['file']['name']))
                $this->uploadPDF($this->db->insert_id(),'berkas', 'file');

            redirect('pegawai/berkas');
            exit;
        }
        $this->data['data']       = $this->Data_berkas_m->get(['id_pegawai' => $this->data['username']]);
        $this->data['title']        = 'Dashboard Admin';
        $this->data['content']      = 'pegawai/berkas';
        $this->template($this->data);
    }
}
