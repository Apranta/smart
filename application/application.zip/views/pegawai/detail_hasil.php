<!-- MAIN -->
        <div class="main">
            <!-- MAIN CONTENT -->
            <div class="main-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4>Hasil Penilaian Akhir</h4>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <style type="text/css">
                                        tr th, tr td {text-align: center; padding: 1%;}
                                    </style>
                                    <h4 class="text-center">Penilaian Tes Tertuls</h4><hr>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>TIU</th>
                                                <th>TKD</th>
                                                <th>TWK</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $nilai = $this->Tes_tertulis_m->get_row(['id_pendaftar' => $user->username]); ?>
                                            <tr>
                                                <td><?= $nilai->tiu ?></td>
                                                <td><?= $nilai->tkd ?></td>
                                                <td><?= $nilai->twk ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <hr>
                                    <h4 class="text-center">Penilaian WAWANCARA</h4><hr>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th rowspan="2" valign="center" style="vertical-align: center !important;">#</th>
                                                <th rowspan="2" valign="center" style="vertical-align: center !important;">Nama</th>
                                                <th colspan="<?= count($this->Kriteria_m->get()) ?>">Kriteria</th>
                                                <th rowspan="2">Total</th>
                                            </tr>
                                            <tr>
                                                <?php foreach ($this->Kriteria_m->get() as $kri): ?>
                                                    <th><?= $kri->nama ?></th>
                                                <?php endforeach ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><?= $user->nama ?></td>
                                                <?php
                                                $total[$user->username] = 0;
                                                foreach ($this->Kriteria_m->get() as $kri): ?>
                                                    <th><?php 
                                                        $nilai = $this->Penilaian_m->get_row(['id_pegawai' => $user->username , 'id_kriteria' => $kri->id]);
                                                        if (!isset($nilai)) {
                                                            $total[$user->username]+=0;
                                                            echo "0";
                                                        }
                                                        else{
                                                            $total[$user->username]+=$nilai->nilai;
                                                            echo $nilai->nilai;
                                                        }
                                                    ?></th>
                                                <?php endforeach ?>
                                                <td><?= $total[$user->username] ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
            </div>
        </div>

            <script>
                $(document).ready(function() {
                    $('.input-group.date').datepicker({format: "yyyy-mm-dd"});
                    
                    $('#dataTables-example').DataTable({
                        responsive: true
                    });
                });
            </script>