<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
            	<div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Data Berkas Administrasi
                        </div>
            		<table class="table table-bordered table-responsive">
            			<thead>
            				<tr>
            					<th>#</th>
            					<th>Nama Calon Pegawai</th>
            					<th>Data Berkas</th>
            					<th>Action</th>
            				</tr>
            			</thead>
            			<tbody>
                            <?php $i=0; foreach ($data as $Pegawai): 
                                $berkas = $this->Data_berkas_m->get(['id_pegawai' => $Pegawai->username]);
                            ?>
            				<tr>
            					<td><?= ++$i  ?></td>
            					<td><?= $Pegawai->nama ?></td>
            					<td>
            						<?php if (!$berkas): ?>
                                        Berkas belum ada
                                    <?php else : ?>
                                    <ul>
                                        <?php foreach ($berkas as $key): ?>
                                            <li><button onclick="view(<?= $key->id ?>)" data-toggle="modal" data-target="#view" class="btn btn-primary"><i class="fa fa-download"></i> <?= $key->nama ?></a></li>
                                        <?php endforeach ?>
                                    </ul>
                                    <?php endif ?>
            					</td>
            					<td>
                                    <?php if ($Pegawai->berkas == 1): ?>
                                        <button class="btn btn-danger" onclick="batal('<?= $Pegawai->username ?>')">BATAL</button>
                                    <?php else : ?>
                                        <button class="btn btn-success" onclick="lulus('<?= $Pegawai->username ?>')">KONFIRMASI</button>
                                    <?php endif ?>
            					</td>
            				</tr>	
                            <?php endforeach ?>
            			</tbody>
            		</table>
                    </div>
            	</div>
            </div>

        <div class="modal fade" tabindex="-1" role="dialog" id="view">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-body" align="center">
              	<iframe id="myImg" height="500px" width="500px"></iframe>
                <!-- <img  class="img img-responsive" id="myImg">             -->
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function view(id_pemesanan) {
        document.getElementById("myImg").src = "<?= base_url('assets/berkas').'/'?>" + id_pemesanan + '.pdf';
    }

    function lulus(username) {
    	// alert('aa');
    	$.ajax({
                url: "<?= base_url('admin/data-berkas') ?>",
                type: 'POST',
                data: {
                    username: username,
                    konfirm: true
                },
                success: function() {
                    window.location = "<?= base_url('admin/data-berkas') ?>";
                }
            });
    }

    function batal(username) {
        // alert('aa');
        $.ajax({
                url: "<?= base_url('admin/data-berkas') ?>",
                type: 'POST',
                data: {
                    username: username,
                    notkonfirm: true
                },
                success: function() {
                    window.location = "<?= base_url('admin/data-berkas') ?>";
                }
            });
    }
</script>