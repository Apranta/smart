<!-- MAIN -->
        <div class="main">
            <!-- MAIN CONTENT -->
            <div class="main-content">
                <div class="container-fluid">
                	<div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Detail Pegawai
                                </div>
                                <div class="panel-body">
                        			<table class="table table-bordered">
                            		<tbody>
                                    	<tr>
                                        	<td></td>
                                    	</tr>
                                    	<tr>
                                    		<td></td>
                                    	</tr>
                            		</tbody>
                        			</table>                    
                    			</div>                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>